#include <iostream>
#include <string.h>
#include <stdlib.h>
using namespace std;
char *encrypto(char *s)
{
    int JZ[2][2] = {0};
    cout << "������������Կ����" << endl;
    for (int i = 0; i < 2; i++)
    {
        for (int j = 0; j < 2; j++)
        {
            cin >> JZ[i][j];
        }
    }
    int len = strlen(s);
    int jishu = 0;
    if (len % 2 == 1)
    {
        s[len] = 'M';
        s[len + 1] = '\0';
        jishu = 1;
    }
    len = strlen(s);
    for (int i = 0; i < len; i++)
    {
        s[i] = s[i] - 'A';
    }
    int a, b, c, d;
    char r2[50];
    for (int i = 0; i < len; i += 2)
    {
        a = s[i];
        b = s[i + 1];
        c = (a * JZ[0][0] + b * JZ[1][0]) % 26;
        d = (a * JZ[0][1] + b * JZ[1][1]) % 26;
        r2[i] = c;
        r2[i + 1] = d;
    }
    if (jishu == 1)
    {
        len -= 1;
    }
    for (int i = 0; i < len; i++)
    {
        s[i] = r2[i] + 'A';
    }
    return s;
}
char *decrypto(char *s)
{
    int JZ[2][2] = {0};
    cout << "������������Կ����" << endl;
    for (int i = 0; i < 2; i++)
    {
        for (int j = 0; j < 2; j++)
        {
            cin >> JZ[i][j];
        }
    }
    int len = strlen(s);
    int jishu = 0;
    if (len % 2 == 1)
    {
        s[len] = 'M';
        s[len + 1] = '\0';
        jishu = 1;
    }
    len = strlen(s);
    for (int i = 0; i < len; i++)
    {
        s[i] = s[i] - 'A';
    }
    int temp = -1;
    for (int i = 1; temp < 0; i++)
    {
        temp = (JZ[0][0] * JZ[1][1] - JZ[0][1] * JZ[1][0]) + 26 * i;
    }
    int i = 1;
    int temp1;
    while (1)
    {
        if ((temp * i) % 26 == 1)
        {
            temp1 = i;
            break;
        }
        else
        {
            i++;
        }
    }
    int JZ2[2][2];
    JZ2[0][0] = JZ[1][1] * temp1;
    JZ2[0][1] = (((-1 * JZ[0][1]) + 26) * temp1) % 26;
    JZ2[1][0] = (((-1 * JZ[1][0]) + 26) * temp1) % 26;
    JZ2[1][1] = JZ[0][0] * temp1;
    int a, b, c, d;
    char r[50];
    for (i = 0; i < len; i += 2)
    {
        a = s[i];
        b = s[i + 1];
        c = (a * JZ[0][0] + b * JZ[1][0]) % 26;
        d = (a * JZ[0][1] + b * JZ[1][1]) % 26;
        r[i] = c;
        r[i + 1] = d;
    }
    if (jishu == 1)
    {
        len -= 1;
    }
    for (i = 0; i < len; i++)
    {
        s[i] = r[i] + 'A';
    }
    return s;
}
int main()
{
    char *text = (char *)malloc(0x50);
    char *result;
    cout << "���������Ļ�����(����д)" << endl;
    cin >> text;
    int type;
    cout << "��������Ҫ���еĲ�����\n1.����\n2.����" << endl;
    cin>>type;
    if (type == 1)
    {
        result = encrypto(text);
        cout << result;
        system("pause");
        return 0;
    }
    else if (type == 2)
    {
        result = decrypto(text);
        cout << result;
        system("pause");
        return 0;
    }
}
