#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#define N 60

int main()
{
    int K[2][2] = {0};
    int Temp1[2] = {0}, Temp2[2] = {0};
    char c[N] = {0}, m[N] = {0}, _c[N] = {0};
    int T1[N] = {0}, T2[N] = {0};
    int lenc, lenm, temp, temp1, i, j;

    printf("����Hill����\n\n");
    printf("��������֪���ģ�\n");
    scanf("%s", c);
    lenc = strlen(c);
    printf("��������֪����(��֤�������4)��\n");
    scanf("%s", m);
    lenm = strlen(m);
    for (i = 0; i < 4; i++)
    {
        if (c[i] >= 'A' && c[i] <= 'Z')
        {
            c[i] = c[i] + 32;
        }

        T1[i] = c[i] - 'a';
    }
    for (i = 0; i < 4; i++)
    {
        if (m[i] >= 'A' && m[i] <= 'Z')
        {
            m[i] = m[i] + 32;
        }

        T2[i] = m[i] - 'a';
    }
    temp = -1;
    for (i = 1; temp < 0; i++)
    {
        temp = (T1[0] * T1[3] - T1[1] * T1[2]) + 26 * i;
    }

    i = 1;
    while (1)
    {
        if ((temp * i) % 26 == 1)
        {
            temp1 = i;
            break;
        }
        else
        {
            i++;
        }
    }

    _c[0] = (T1[3] * temp1) % 26;
    _c[1] = (((-1 * T1[1] + 26)) * temp1) % 26;
    _c[2] = (((-1 * T1[2] + 26)) * temp1) % 26;
    _c[3] = (T1[0] * temp1) % 26;
    K[0][0] = (T2[0] * _c[0] + T2[2] * _c[1]) % 26;
    K[0][1] = (T2[1] * _c[0] + T2[3] * _c[1]) % 26;
    K[1][0] = (T2[0] * _c[2] + T2[2] * _c[3]) % 26;
    K[1][1] = (T2[1] * _c[2] + T2[3] * _c[3]) % 26;

    printf("��ԿΪ:");
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 2; j++)
        {
            printf("%d ", K[i][j]);
        }
    }

    return 0;
}
