#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int encrypt(char *text, char *result, int a, int b)
{
    int i = 0, j = 0;
    int len = strlen(text);
    for (i = 0; i < len; i++)
    {
        if (text[i] >= 'A' && text[i] <= 'Z')
        {
            result[i] = (a * (text[i] - 'A') + b) % 26 + 'A';
        }
        else if (text[i] >= 'a' && text[i] <= 'z')
        {
            result[i] = (a * (text[i] - 'a') + b) % 26 + 'a';
        }
        else
        {
            result[i] = text[i];
        }
    }
    return 0;
}
int decrypt(char *text, char *result, int c, int d)
{
    int i = 0, j = 0;
    int len = strlen(text);
    for (i = 0; i < len; i++)
    {
        if (text[i] >= 'A' && text[i] <= 'Z')
        {
            result[i] = (c * ((text[i] - 'A') - d)) % 26 + 'A';
            if (c * ((text[i] - 'A') - d) < 0)
            {
                result[i] = result[i] + 26;
            }
        }
        else if (text[i] >= 'a' && text[i] <= 'z')
        {
            result[i] = (c * ((text[i] - 'a') - d)) % 26 + 'a';
            if (c * ((text[i] - 'a') - d) < 0)
            {
                result[i] = result[i] + 26;
            }
        }
        else
        {
            result[i] = text[i];
        }
    }
    return 0;
}
int re(int x)
{
    for (int i = 1; i <= 25; i++)
    {
        if ((x * i) % 26 == 1)
        {
            return i;
        }
    }
    return -1;
}
int main()
{
    char text[50] = "";
    char result[50] = "";
    int k1, k2, k3;2
    int type;
    printf("��ѡ����ܷ�ʽ������1���ܣ�����2����\n");
    scanf("%d", &type);
    printf("����д���Ļ�������\n");
    scanf("%s", text);
    if (type == 1)
    {
        printf("��������Կa\n");
        scanf("%d", &k1);
        printf("��������Կb\n");
        scanf("%d", &k2);
        encrypt(text, result, k1, k2);
        printf("����%s������Ϊ:%s\n", text, result);
    }
    else if (type == 2)
    {
        printf("��������Կk1\n");
        scanf("%d", &k3);
        printf("��������Կk2\n");
        scanf("%d", &k2);
        k3 = re(k3);
        if (k3 == -1)
        {
            printf("k1��26�����أ��޷�����");
        }
        decrypt(text, result, k3, k2);
        printf("����%s������Ϊ:%s\n", text, result);
    }
    system("pause");
    return 0;
}