#设采用的轮函数为：F(Ri-1，Ki)=(Ri-1)⊕(Ki)
def encrypt(s1,s2,key):#每次传4个字符
    result=''
    for i in range(0,4):
        temp=ord(s1[i])^ord(s2[i])^ord(key[i])
        result+=chr(temp)
    return result

def encode(plaintext,keylist):
    ciphertext=''
    for i in range(0,len(plaintext)//8):   #每8个字符划分成一组加密
        temp=plaintext[i*8:(i+1)*8]
        L=temp[:4]                     #每组分为2部分
        R=temp[4:]
        for key in keylist:
            temp2=R
            R=encrypt(L,R,key)        #Ri=Li-1⊕F(Ri-1，Ki)
            L=temp2                   #Li=Ri-1
        ciphertext+=R+L
    return ciphertext

def Feistel():
    key=[]
    plaintext=input("请输入要加密的字符串(需要为8的整数）:")
    num=int(input("请输入加密循环的次数"))
    for i in range(0,num):
        temp=input('请输入第'+str(i)+'组加密时使用的密钥（4个字符）:')
        key.append(temp)
    ciphertext=encode(plaintext,key)
    print('密文：',ciphertext)

    key.reverse()
    plaintext=encode(ciphertext,key)
    print('解密后的明文：',plaintext)

Feistel()