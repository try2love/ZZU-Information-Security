from DES_BOX import *


def str_bit(message):
    """
    :param message: 字符串
    :return: 将输入的字符串转化为01比特流序列
    """
    bits = ""
    for i in message:
        asc2i = bin(ord(i))[2:]  # bin将十进制转为二进制数会带有0b，[2:]去除0b
        for i in range(8 - len(asc2i)):
            asc2i = '0' + asc2i
        bits += asc2i
    return bits

def process_key(key):
    """
    key : 输入的密钥字符串
    return : 64bit 01序列密钥(采用偶校验的方法)
    """
    key_bits = ""
    for i in key:
        count = 0
        asc2i = bin(ord(i))[2:]
        '''将每一个ascii均补齐7位,第8位作为奇偶效验位'''
        for j in asc2i:
            count += int(j)
        if count % 2 == 0:
            asc2i += '0'
        else:
            asc2i += '1'
        for j in range(7 - len(asc2i)):
            asc2i = '0' + asc2i
        key_bits += asc2i
    if len(key_bits) > 64:
        return key_bits[0:64]
    else:
        for i in range(64 - len(key_bits)):
            key_bits += '0'
        return key_bits


def divide(bits, bit):
    """

    :param bits: 将01bit俺bit一组进行分组
    :param bit: bit一组的长度
    :return: 按bit分组后得到的列表
    """

    m = len(bits) // bit
    r = len(bits) % bit
    N = ["" for i in range(m)]
    for i in range(m):
        N[i] = bits[i * bit:(i + 1) * bit]
    # 如果最后一组数不足则补0
    if r != 0:
        N.append(bits[m * bit:])
        for i in range(bit - r):
            N[m] += '0'
    return N


def IP_charge(bits):
    """
    :param bits:一组64位的01比特字符串
    :return: 初始置换IP后的64bit01序列
    """
    ip_str = ""
    for i in IP:
        ip_str = ip_str + bits[i - 1]
    return ip_str


def PC_1_chang(key):
    """
    :param key: 64bit有效密钥01bit字符串
    :return: 密钥置换PC_1后的56bit01字符串
    """
    pc_1 = ""
    for i in PC_1:
        pc_1 = pc_1 + key[i - 1]
    return pc_1


def key_leftshift(key_str, num):
    """
    :param key_str:置换后PC_1后的28bit01字符串
    :param num:移动的位数
    :return: 28bit01字符串左移num位后的结果
    """
    left = key_str[num:28]
    left += key_str[0:num]
    return left


def PC_2_charge(key):
    """
    :param key: 56bit意味后的01字符串
    :return: 密钥置换PC_2后的48bit序列字符串
    """
    pc_2 = ""
    for i in PC_2:
        pc_2 = pc_2 + key[i - 1]
    return pc_2


def generate_key(key):
    """
    :param key:64bit01密钥序列
    :return: 16轮的16个48bit01密钥序列按1-16顺序
    """
    key_list = ["" for i in range(16)]
    key = PC_1_chang(key)  # 置换PC_1
    key_left = key[0:28]
    key_right = key[28:]
    for i in range(len(SHIFT)):
        key_left = key_leftshift(key_left, SHIFT[i])
        key_right = key_leftshift(key_right, SHIFT[i])
        key_i = PC_2_charge(key_left + key_right)  # 置换PC_2
        key_list[i] = key_i
    return key_list


def E_change(bits):
    """
    :param bits: 32bit01序列字符串
    :return: 扩展置换E后的48bit01字符串
    """
    e = ""
    for i in E:
        e = e + bits[i - 1]
    return e


def xor(bits, ki):
    """
    :param bits: 48bit01字符串/32bit01 F函数输出
    :param ki: 48bit01密钥序列/32bit01  L_i-1
    :return: bits与ki异或运算得到的48bit01 / 32bit0
    """
    bits_xor = ""
    for i in range(len(bits)):
        if bits[i] == ki[i]:
            bits_xor += '0'
        else:
            bits_xor += '1'
    return bits_xor


def s_search(bits, i):
    """
    :param bits: 6bit01字符串
    :param i: 使用第i个s盒
    :return: 4bit01字符串-S盒的输出
    """
    row = int(bits[0] + bits[5], 2)
    col = int(bits[1:5], 2)
    num = bin(S[i - 1][row * 16 + col])[2:]
    for i in range(4 - len(num)):
        num = '0' + num
    return num


def S_change(bits):
    """
    :param bits: 异或后的48bit01字符串
    :return: 经过S盒后的32bits
    """
    s_change = ""
    for i in range(8):
        temp = bits[i * 6:(i + 1) * 6]
        temp = s_search(temp, i + 1)
        s_change += temp
    return s_change


def P_change(bits):
    """
    :param bits: 经过S盒后的32bit01字符串
    :return: 置换P后的32bit01输出序列
    """
    p = ""
    for i in P:
        p = p + bits[i - 1]
    return p


def F(bits, ki):
    """
    :param bits:32bit 01 Ri输入
    :param ki: 48bit 第i轮密钥
    :return: F函数输出的32bit01序列串
    """
    bits = xor(E_change(bits), ki)
    bits = P_change(S_change(bits))
    return bits


def IP_RE_change(bits):
    """
    :param bits: 经过16轮迭代的64bit01字符串
    :return: 逆初始置换得到的64bit密文01字符串
    """
    ip_re = ""
    for i in IP_RE:
        ip_re += bits[i - 1]
    return ip_re


def des_encrypt(bits, key):
    """
    :param bits: 分组64bit 01明文字符串
    :param key: 64bit01字符串
    :return: 加密后得到的64bit01密文序列
    """
    bits = IP_charge(bits)
    L = bits[0:32]
    R = bits[32:]
    key_list = generate_key(key)  # 16个密钥
    for i in range(16):
        R_temp = R
        R = xor(L, F(R, key_list[i]))
        L = R_temp
    result = IP_RE_change(R + L)
    return result


def bit_str(bits):
    """
    :param bits:01比特串(长度是8的倍数)
    :return: 对应的字符串
    """
    temp = ""
    for i in range(len(bits) // 8):
        temp += chr(int(bits[i * 8:(i + 1) * 8], 2))
    return temp


def all_des_encrypt(message, key):
    """
    :param message:
    :param key:
    :return:
    """
    message = str_bit(message)
    key = process_key(key)
    mess_div = divide(message, 64)
    result = ""
    for i in mess_div:
        result += des_encrypt(i, key)
    return result


def main():
    message = input("请输入要加密的密文：")
    message = message.replace(" ", "")
    key = input("请输入您所设置的密钥：")
    print("Plaintext:  " + message)
    print("Plaintext 01bits:   " + str_bit(message))
    result = all_des_encrypt(message, key)
    print("\nCiphertext 01bits:  " + result)
    result_str = bit_str(result)
    print("Ciphertext:  " + result_str)


if __name__ == '__main__':
    main()
