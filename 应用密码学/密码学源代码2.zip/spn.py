s={'0':'E','1':'4','2':'D','3':'1','4':'2','5':'F','6':'B','7':'8','8':'3','9':'A','A':'6','B':'C','C':'5','D':'9','E':'0','F':'7'}
p={'1':'1','2':'5','3':'9','4':'13','5':'2','6':'6','7':'10','8':'14','9':'3','10':'7','11':'11','12':'15','13':'4','14':'8','15':'12','16':'16'}

k='00111010100101001101011000111111'
w='0010011010110111'


def spn(message):
    w=message
   # print(w)
    for i in range(3):
        keyA=creatKey(i)
    #print(keyA)
        u=kxor(w,keyA)
        v=sw(u)
        w=pw(v)
    keyA=creatKey(3)
    u=kxor(w,keyA)
    w=sw(u)
    keyA=creatKey(4)
    enmessage=kxor(w,keyA)

    return enmessage


def kxor(w,keyA):
    u=''
    for j in range(16):######1
        u+=str(int(w[j])^int(keyA[j]))
    return u    


def creatKey(i):
    key=k[0+4*i:16+4*i]
    return key


def sw(u):
    v=''
    for a in range(4):######2
        v+=bin(int(s.get(hex(int(u[0+4*a:4+4*a],2))[2:].upper()),16))[2:].zfill(4)
    return v


def pw(v):
    w=''
    for b in range(1,17):#########3
        w+=v[int(p.get(str(b)))-1]
    return w


print(spn(w))    




