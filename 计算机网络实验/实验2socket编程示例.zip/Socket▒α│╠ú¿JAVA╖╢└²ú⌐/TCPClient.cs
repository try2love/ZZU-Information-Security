using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Net;
using System.Net.Sockets;

namespace client
{
      class class1

     {
          static void Main(string[] args)
          {
             try
             {
               int port = 2000;
               string host = "127.0.0.1";
               IPAddress ip = IPAddress.Parse(host);
               IPEndPoint ipe = new IPEndPoint(ip,port);//��ip�Ͷ˿�ת��ΪIPEndPointʵ��
               Socket c = new Socket(AddressFamily.InterNetwork,SocketType.Stream,ProtocolType.Tcp);//����һ��Socket
               Console.WriteLine("Conneting...");
               c.Connect(ipe);//���ӵ�������
               string sendStr="hello!This is a socket test";
               byte[] bs=Encoding.ASCII.GetBytes(sendStr);
               Console.WriteLine("SendMessage");
               c.Send(bs,bs.Length,0);//���Ͳ�����Ϣ
               string recvStr="";
               byte[]recvBytes = newbyte[1024];
               int bytes;
               bytes = c.Receive(recvBytes,recvBytes.Length,0);//�ӷ������˽��ܷ�����Ϣ
               recvStr += Encoding.ASCII.GetString(recvBytes,0,bytes);
               Console.WriteLine("ClientGetMessage:{0}",recvStr);//��ʾ������������Ϣ
               c.Close();
             }
             catch(ArgumentNullException e)
             {
               Console.WriteLine("ArgumentNullException:{0}",e);
             }
             catch(SocketException e)
             {
               Console.WriteLine("SocketException:{0}",e);
             }
             Console.WriteLine("PressEntertoExit");
             Console.ReadLine();
           }        
      }
}