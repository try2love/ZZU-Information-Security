
def num_to_str(num):
    list_str = []
    list_num = []
    for i in range(26):
        list_num.append(i)
        a = chr(i + 65)
        list_str.append(a)
    my_map = dict(map(lambda x, y: [x, y], list_num, list_str))  #生成 数字：字符 的字典
    print(my_map[num], end='')


def str_to_num(str):
    list_str = []
    list_num = []
    for i in range(26):
        list_num.append(i)
        a = chr(i + 65)
        list_str.append(a)
    my_map = dict(map(lambda x, y: [x, y], list_str, list_num))  #生成 字符：数字 的字典
    return my_map[f'{str}']


def encode():
    str = input("请输入您要进行加密的字符(请输入大写字符)：")
    a = input("请输入加密的密钥：")
    print('加密后的结果为：', end='')
    j = 0
    for i in str:
        if i.isspace():
            print(' ', end='')
        else:

            result = (str_to_num(i) + str_to_num(a[j%len(a)])) % 26  #密文=（明文+密钥）mod 26  密钥轮流使用
            j = j + 1
            num_to_str(result)
    print('\n')


def decode():
    str = input("请输入您要进行解密的字符(请输入大写字符)：")
    a = input("请输入解密的密钥：")
    print('解密后的结果为：', end='')
    j = 0
    for i in str:
        if i.isspace():
            print(' ', end='')
        else:
            result = (str_to_num(i) - str_to_num(a[j%len(a)])) % 26  #明文=（密文-密钥）mod 26  密钥轮流使用
            j = j + 1
            num_to_str(result)
    print('\n')


if __name__ == "__main__":
    while True:
        temp = input("请输入您要进行编码还是解码：(编码：E 解码：D 退出：0 ):")
        if temp == 'E' or temp == 'e':
            encode()
        elif temp == 'D' or temp == 'd':
            decode()
        elif temp == '0':
            break
        else:
            print("输入有误，请再次输入")
