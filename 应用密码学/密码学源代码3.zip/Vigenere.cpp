#include <iostream>
#include <string>
#include <string.h>
using namespace std;
char *encrypto(char *m, char *s)
{
    int len1 = strlen(s);
    int len2 = strlen(m);
    int j = 0;
    for (int i = 0; i < len2; i++)
    {
        m[i] = ((m[i] - 'A') + (s[j] - 'A')) % 26 + 'A';
        j++;
        if (j == (len1))
            j = 0;
    }
    return m;
}
char *decrypto(char *m, char *s)
{
    int len1 = strlen(s);
    int len2 = strlen(m);
    int j = 0;
    for (int i = 0; i < len2; i++)
    {
        m[i] = ((m[i] - 'A') - (s[j] - 'A')) % 26;
        if (m[i] < 0)
            m[i] + 26;
        m[i] += 'A';
        j++;
        if (j == (len1))
            j = 0;
    }
    return m;
}
int main()
{
    char s[50];
    cout << "�����������Կ��(�������д��ĸ)" << endl;
    cin >> s;
    cout << "��ѡ�����Ĳ�����\n1.����\n2.����" << endl;
    int type;
    cin >> type;
    cout << "��������������/���ģ�" << endl;
    char m[50];
    cin >> m;
    if (type == 1)
    {
        char *miwen1;
        miwen1 = encrypto(m, s);
        cout << miwen1;
    }
    else if (type == 2)
    {
        char *mingwen2;
        mingwen2 = decrypto(m, s);
        cout << mingwen2;
    }
    system("pause");
}