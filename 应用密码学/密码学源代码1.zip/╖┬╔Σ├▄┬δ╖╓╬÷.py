from scipy import linalg
import numpy as np
from gmpy2 import invert

def num_to_str(num):
    list_str = []
    list_num = []
    for i in range(26):
        list_num.append(i)
        a = chr(i + 65)
        list_str.append(a)
    my_map = dict(map(lambda x, y: [x, y], list_num, list_str))  #生成 数字：字符 的字典
    print(my_map[num], end='')


def gcd(a, b):
    while a != 0:
        a, b = b % a, a
    return b


def str_to_num(str):
    list_str = []
    list_num = []
    for i in range(26):
        list_num.append(i)
        a = chr(i + 65)
        list_str.append(a)
    my_map = dict(map(lambda x, y: [x, y], list_str, list_num)) #生成 字符：数字 的字典
    return my_map[f'{str}']


s = input("请输入密文（请输入大写字符）：")
result = {}
frequency = 'E T A O I N S H R D L C U M W F G Y P B V K J X Q Z'  #密文的字母出现频率
frequency_list = frequency.split()                                 #生成频率列表
print(frequency_list)
for i in s:
    result[i] = s.count(i)                                        #计算密文中字母的频率，并生成字典
print(result)
max_key = max(result, key=result.get)                             #找出当前密文中频率最高的字母并删除字典中相应的键值对
del result[max_key]
cipher_a = str_to_num(max_key)
plain_a = str_to_num(frequency_list[0])                           #假设plain_a，b是对应频率最高的两个字母
plain_b=str_to_num(frequency_list[1])
temp=1
while True:
    flag=True
    if not bool(result):                                #进行下一轮的假设搜索，即上一轮将result中的函数都删除完了，仍然没有得到正确的明文
        for i in s:
            result[i] = s.count(i)
        max_key = max(result, key=result.get)
        del result[max_key]
        temp = temp + 1
        if len(frequency_list)<=temp:                  #进行的总轮数比频率表的长度都多，就退出
            flag=False
            break
        plain_b = str_to_num(frequency_list[temp])
    max_key = max(result, key=result.get)             #找出当前密文中频率最高的字母并删除字典中相应的键值对
    if flag==False:
        break
    del result[max_key]
    cipher_b = str_to_num(max_key)
    A = np.array([[plain_a, 1], [plain_b, 1]])  #线性方程等号左边的系数
    B = np.array([cipher_a, cipher_b])         #线性方程等号右边的系数
    x = linalg.solve(A, B)                #求解线性次方程组

    if gcd(int(x[0]), 26) == 1:           #通过解密寻找可能的明文
        print('明文可能为：', end='')
        for i in s:
            if i.isspace():
                print(' ', end='')
            else:
                plaintext = (invert(int(x[0]), 26) * (str_to_num(i) - int(x[1]))) % 26
                num_to_str(plaintext)
        print('\n')
