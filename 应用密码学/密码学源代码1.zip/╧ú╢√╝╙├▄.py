import string

import numpy as np

def encode():
    plaintext = input("请输入您要进行加密的字符(请输入大写字符)：")
    num = int(input("请选择加密矩阵的大小n作为n*n的加密矩阵(请务必保证矩阵合法)"))
    print("请输入", num, "行", num, '列，每个数字之间用空格隔开')
    key = input()
    key_list=key.split()
    key_list=[int(x)for x in key_list]
    matrix=np.array(key_list).reshape(num,num)  #将key_list转化为三行三列的数组
    print('加密矩阵为：')
    for i in range(num):
        for j in range(num):
            print(matrix[i][j], end='')
            if j == (num - 1):
                print('')
            else:
                print(' ', end=' ')
    temp=[]
    plaintext_list=[]
    count=1
    for i in  plaintext:                    #生成明文列表,里面含有num个列表，其中每个列表含有num个元素
        temp.append(ord(i)-ord('A'))
        if count%num==0:
            plaintext_list.append(temp)
            temp=[]
        count+=1
    ciphertext=[np.matrix(i).T for i in  plaintext_list]  #将列表转化为n行n列的矩阵并转置
    encrypted=[(matrix*i)%26 for i in ciphertext]       #将转置矩阵的每一行与加密矩阵相乘 并mod26
    ciphertext_list=[]
    for i in encrypted:
        temp=i.tolist()
        for j in range(num):
            ciphertext_list.append(temp[j][0])
    c=[chr(i+ord('A')) for i in ciphertext_list]
    print(''.join(c))

def decode():
    ciphertext = input("请输入您要进行解密的字符(请输入大写字符)：")
    num = int(input("请选择加密矩阵的大小n作为n*n的加密矩阵(请务必保证矩阵合法)"))
    print("请输入", num, "行", num, '列，每个数字之间用空格隔开')
    key = input()
    key_list=key.split()
    key_list=[int(x)for x in key_list]
    matrix_reverse=np.array(key_list).reshape(num,num)    #将key_list转化为三行三列的数组
    print('解密逆矩阵为：')
    for i in range(num):
        for j in range(num):
            print(matrix_reverse[i][j], end='')
            if j == (num - 1):
                print('')
            else:
                print(' ', end=' ')
    temp=[]
    ciphertext_list=[]
    count=1
    for i in ciphertext:                  #生成密文列表,里面含有num个列表，其中每个列表含有num个元素
        temp.append(ord(i)-ord('A'))
        if count%num==0:
            ciphertext_list.append(temp)
            temp=[]
        count+=1
    ciphertext=[np.matrix(i).T for i in  ciphertext_list]  #将列表转化为n行n列的矩阵并转置
    decrypted=[(matrix_reverse*i)%26 for i in ciphertext]  #将转置矩阵的每一行与加密矩阵相乘 并mod26
    plaintext_list=[]
    for i in decrypted:
        temp=i.tolist()
        for j in range(num):
            plaintext_list.append(temp[j][0])
    c=[chr(i+ord('A')) for i in plaintext_list]
    print(''.join(c))



if __name__ == "__main__":
    while True:
        temp = input("请输入您要进行编码还是解码：(编码：E 解码：D 退出：0 ):")
        if temp == 'E' or temp == 'e':
            encode()
        elif temp == 'D' or temp == 'd':
            decode()
        elif temp == '0':
            break
        else:
            print("输入有误，请再次输入")
