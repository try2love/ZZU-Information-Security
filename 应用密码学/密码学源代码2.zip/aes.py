Rocn=[['00000001','00000000','00000000','00000000'],
['00000010','00000000','00000000','00000000'],
['00000100','00000000','00000000','00000000'],
['00001000','00000000','00000000','00000000'],
['00001010','00000000','00000000','00000000'],
['00100000','00000000','00000000','00000000'],
['01000001','00000000','00000000','00000000'],
['10000001','00000000','00000000','00000000'],
['00011011','00000000','00000000','00000000'],
['00110110','00000000','00000000','00000000']]###############密钥拓展需要的Rocn矩阵

tll=[['00000010', '00000011', '00000001', '00000001'], 
['00000001', '00000010', '00000011', '00000001'], 
['00000001', '00000001', '00000010', '00000011'], 
['00000011', '00000001', '00000001', '00000010']]###########进行列混合的系数矩阵

S1=[['63', '7c', '77', '7b', 'f2', '6b', '6f', 'c5', '30', '01', '67', '2b', 'fe', 'd7', 'ab', '76'], 
['ca', '82', 'c9', '7d', 'fa', '59', '47', 'f0', 'ad', 'd4', 'a2', 'af', '9c', 'a4', '72', 'c0'], 
['b7', 'fd', '93', '26', '36', '3f', 'f7', 'cc', '34', 'a5', 'e5', 'f1', '71', 'd8', '31', '15'], 
['04', 'c7', '23', 'c3', '18', '96', '05', '9a', '07', '12', '80', 'e2', 'eb', '27', 'b2', '75'], 
['09', '83', '2c', '1a', '1b', '6e', '5a', 'a0', '52', '3b', 'd6', 'b3', '29', 'e3', '2f', '84'], 
['53', 'd1', '00', 'ed', '20', 'fc', 'b1', '5b', '6a', 'cb', 'be', '39', '4a', '4c', '58', 'cf'], 
['d0', 'ef', 'aa', 'fb', '43', '4d', '33', '85', '45', 'f9', '02', '7f', '50', '3c', '9f', 'a8'], 
['51', 'a3', '40', '8f', '92', '9d', '38', 'f5', 'bc', 'b6', 'da', '21', '10', 'ff', 'f3', 'd2'], 
['cd', '0c', '13', 'ec', '5f', '97', '44', '17', 'c4', 'a7', '7e', '3d', '64', '5d', '19', '73'], 
['60', '81', '4f', 'dc', '22', '2a', '90', '88', '46', 'ee', 'b8', '14', 'de', '5e', '0b', 'db'], 
['e0', '32', '3a', '0a', '49', '06', '24', '5c', 'c2', 'd3', 'ac', '62', '91', '95', 'e4', '79'], 
['e7', 'c8', '37', '6d', '8d', 'd5', '4e', 'a9', '6c', '56', 'f4', 'ea', '65', '7a', 'ae', '08'], 
['ba', '78', '25', '2e', '1c', 'a6', 'b4', 'c6', 'e8', 'dd', '74', '1f', '4b', 'bd', '8b', '8a'], 
['70', '3e', 'b5', '66', '48', '03', 'f6', '0e', '61', '35', '57', 'b9', '86', 'c1', '1d', '9e'], 
['e1', 'f8', '98', '11', '69', 'd9', '8e', '94', '9b', '1e', '87', 'e9', 'ce', '55', '28', 'df'], 
['8c', 'a1', '89', '0d', 'bf', 'e6', '42', '68', '41', '99', '2d', '0f', 'b0', '54', 'bb', '16']]


#message=input('请输入16个英文字母:')
#Key=input('请输入加密密钥:')
message='abcdefghijklmnop'
Key='abcdefghijklmnop'

W=[0]*(44)##############密钥拓展矩阵


def zhunbei(message):#################################把输入的16位字母转换成128为比特流
    s=''
    for i in message:
        s+=hex(ord(i))[2:]
    s=format(bin(int(s,16))[2:].zfill(len(message)*8),'0<128')
    return s

def jiehe(t):
    c=''
    for i in range(4):
        for j in range(4):
            c+=t[j][i]
    d=''
    for i in range(32):
        d+=hex(int(c[4*i:4*(i+1)],2))[2:]
    return d

def juzhen(s):#################################把输入的16位字母转换成状态矩阵
    c=[]
    for i in range(4):
        b=[]
        for j in range(4):
            b.append(s[32*j+8*i:32*j+8*(i+1)])
        c.append(b)
    return c

def byte(s,x):###############################字节代换，对于密钥拓展是0.对铭文状态矩阵是1
    if x==0:
        for j in range(4):
            high=int(s[j][:4],2)
            low=int(s[j][4:],2)
            t=S1[high][low]
            s[j]=bin(int(t[0],16))[2:].zfill(4)+bin(int(t[1],16))[2:].zfill(4)
    else:
        for i in range(4):
            for j in range(4):
                high=int(s[i][j][:4],2)
                low=int(s[i][j][4:],2)
                t=S1[high][low]
                s[i][j]=bin(int(t[0],16))[2:].zfill(4)+bin(int(t[1],16))[2:].zfill(4)
    return s

def hangyiwei(t):
    for i in range(4):
        t[i]=t[i][i:]+t[i][:i]
    return t

def Max(tll,t):########################进行GF(2**32-1)次方的幂运算
    if tll=='00000001':
        return int(t,2)
    elif tll=='00000010':
        if t[0]=='0':
            return int(t[1:]+'0',2)
        else:
            return int(t[1:]+'0',2)^int('00011011',2)
    else:
        return Max('00000001',t)^Max('00000010',t)

def liehunhe(t):
    t1=[]
    for i in range(4):
        t2=[0,0,0,0]
        for j in range(4):
            t2[0]^=Max(tll[i][j],t[0][j])
            t2[1]^=Max(tll[i][j],t[1][j])
            t2[2]^=Max(tll[i][j],t[2][j])
            t2[3]^=Max(tll[i][j],t[3][j])
        for k in range(4):
            t2[k]=bin(int(str(t2[k]).zfill(2)[0],16))[2:].zfill(4)+bin(int(str(t2[k]).zfill(2)[1],16))[2:].zfill(4)
        t1.append(t2)
    return t1

def Makekey(i,W):####i从0开始
    if i==0:
        for i in range(4):
            W[i]=Key[32*i:32*(i+1)]
        return W
    else:
        for j in range(4*i,4*(i+1)):
            if j%4==0:
                s1=W[j-4]
                s2=T(W[j-1],j//4)
                s3=''
                for i in range(32):
                    s3+=str((int(s1[i])+int(s2[i]))%2)
                W[j]=s3                          
            else:
                s1=W[j-4]
                s2=W[j-1]
                s3=''
                for i in range(32):
                    s3+=str((int(s1[i])+int(s2[i]))%2)
                W[j]=s3          
        return W


def T(a,j):##########a是传入的密钥矩阵，j是密钥矩阵的下标索引
    b=[]
    for i in range(4):
        b.append(a[8*i:8*(i+1)])
    b=b[1:]+b[0:1]
    b=byte(b,0)  
    c=''
    for i in range(4):
        xx=int(b[i],2)^int(Rocn[j-1][i],2)
        if len(str(xx))==1:
            b[i]='0000'+bin(xx)[2:].zfill(4)
        elif len(str(xx))==2:
            b[i]=bin(int(str(xx)[0]))[2:].zfill(4)+bin(int(str(xx)[1]))[2:].zfill(4)
        else:
            b[i]=bin(xx)[2:].zfill(8)
        c+=b[i]
    return c

def lunmiyaojia(t,i):#########W是轮密钥矩阵，i是轮数
    global W
    W=Makekey(i,W)
    for j in range(4):
        a=''
        for k in range(4):
            a+=t[k][j]
        a1=bin(int(a,2)^int(W[4*i+j],2))[2:].zfill(32)
        for k in range(4):
            t[k][j]=a1[8*k:8*(k+1)]
    return t


s=zhunbei(message)####把输入的16位字符转化为128为01比特
Key=zhunbei(Key)
messageed=juzhen(s)####明文的状态矩阵
t=lunmiyaojia(messageed,0)

for i in range(1,10):
    tb=byte(t,1)
    th=hangyiwei(tb)
    tl=liehunhe(th)
    t=lunmiyaojia(tl,i)


tb=byte(t,1)
th=hangyiwei(tb)
t=lunmiyaojia(th,10)
print(jiehe(t))



