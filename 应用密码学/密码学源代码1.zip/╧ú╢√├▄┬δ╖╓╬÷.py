import numpy as np
num = int(input("请选择加密矩阵的大小n作为n*n的加密矩阵： "))
plaintext = input("请输入您要进行加密的字符(请输入大写字符)：")
temp=[]
plaintext_list=[]
count = 1
for i in plaintext:
    temp.append(ord(i) - ord('A'))
    if count % num == 0:
        plaintext_list.append(temp)
        temp = []
    count += 1
plain_matrix=np.array(plaintext_list).reshape(num,num)      #转化位明文矩阵num×num
print("明文矩阵为：\n",plain_matrix)
ciphertext = input("请输入您要进行解密的字符(请输入大写字符)：")
ciphertext_list=[]
temp=[]
count = 1
for i in ciphertext:
    temp.append(ord(i) - ord('A'))
    if count % num == 0:
        ciphertext_list.append(temp)
        temp = []
    count += 1
ciphertext_matrix=np.array(ciphertext_list).reshape(num,num)  #计算密文矩阵 num×num
print("密文矩阵为：\n",ciphertext_matrix)
plain_reverse=np.linalg.inv(plain_matrix)                     #求明文矩阵逆并mod26
plain_reverse=np.mod(plain_reverse,26)
key_matrix=np.dot(plain_reverse,ciphertext_matrix)            #计算 密钥矩阵=明文逆矩阵与密文矩阵的乘积并mod26
key_matrix=np.mod(key_matrix,26)
print("密钥矩阵为：")
print(key_matrix)