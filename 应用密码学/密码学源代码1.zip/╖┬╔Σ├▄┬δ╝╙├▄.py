from gmpy2 import invert


def num_to_str(num):
    """
    :param num: 输入的数字
    :return: 将数字转化为对应的字符
    """
    list_str = []
    list_num = []
    for i in range(26):
        list_num.append(i)
        a = chr(i + 65)
        list_str.append(a)
    my_map = dict(map(lambda x, y: [x, y], list_num, list_str))  #生成 数字：字符 的字典
    print(my_map[num], end='')


def str_to_num(str):
    list_str = []
    list_num = []
    for i in range(26):
        list_num.append(i)
        a = chr(i + 65)
        list_str.append(a)
    my_map = dict(map(lambda x, y: [x, y], list_str, list_num)) #生成 字符：数字 的字典
    return my_map[f'{str}']


def encode():
    str = input("请输入需要编码的字符(请输入大写字符）：")
    a = int(input('请输入a：'))
    b = int(input('请输入b: '))
    print('编码后的结果为：', end='')
    for i in str:
        if i.isspace():
            print(' ', end='')
        else:
            result = (a * str_to_num(i) + b) % 26
            num_to_str(result)
    print('\n')


def decode():
    str = input("请输入需要解码的字符（请输入大写字符）：")
    a = int(input('请输入a：'))
    b = int(input('请输入b: '))
    print('解码后的结果为：', end='')
    for i in str:
        if i.isspace():
            print(' ', end='')
        else:
            result = (invert(a, 26) * (str_to_num(i) - b)) % 26  #invert（a，b）求a模b的逆元
            num_to_str(result)
    print('\n')


if __name__ == "__main__":
    while True:
        temp = input("请输入您要进行编码还是解码：(编码：E 解码：D ):")
        if temp == 'E' or temp == 'e':
            encode()
            break
        elif temp == 'D' or temp == 'd':
            decode()
            break
        else:
            print("输入有误，请再次输入")
