def encode(dictionary):
    plaintext=input("请输入要加密的明文：")
    print("密文为： ")
    for i in plaintext:
        print(dictionary.get(i),end='')
    print('\n')

def decode(dictionary):
    reverse_dictionary=dict([(value,key) for (key,value) in dictionary.items()])  #将字典的键值对反转
    ciphertext=input("请输入要解密的密文：")
    print("明文为： ")
    for i in ciphertext:
        print(reverse_dictionary.get(i),end='')
    print('\n')
if __name__ == "__main__":
    a = []
    b = []
    for i in range(97, 123):
        a.append(chr(i))
    temp = input("请写入A-Z对应的的映射（请输入大写字母）:")
    b = temp.split()  #去除空格
    dictionary = dict(zip(a, b))  #生产映射的字典
    while True:
        temp = input("请输入您要进行编码还是解码：(编码：E 解码：D 退出：0 ):")
        if temp == 'E' or temp == 'e':
            encode(dictionary)
        elif temp == 'D' or temp == 'd':
            decode(dictionary)
        elif temp == '0':
            break
        else:
            print("输入有误，请再次输入")
