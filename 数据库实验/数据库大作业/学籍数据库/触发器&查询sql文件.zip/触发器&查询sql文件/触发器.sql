CREATE TRIGGER dynamic_yueshu
--�ڳɼ������޸ĳɼ�ʱ���Զ��޸�ѧ����ѧ��
ON sc
AFTER UPDATE
AS
BEGIN
	declare @sno int,@cno int,@grade int
	select @sno=sno,@cno=cno,@grade=grade
		from inserted
	if @grade>=90 and @grade<=100
		update sc
		set credit=course.ccredit
		from course inner join sc
		on sc.cno=course.cno
		where sno=@sno and @cno=sc.cno
	else if @grade>=80 and @grade<90
		update sc
		set credit=course.ccredit*0.7
		from course inner join sc
		on sc.cno=course.cno
		where sno=@sno and @cno=sc.cno
	else if @grade>=70 and @grade<80
		update sc
		set credit=course.ccredit*0.5
		from course inner join sc
		on sc.cno=course.cno
		where sno=@sno and @cno=sc.cno
	else if @grade>=60 and @grade<70
		update sc
		set credit=course.ccredit*0.3
		from course inner join sc
		on sc.cno=course.cno
		where sno=@sno and @cno=sc.cno
	else
		update sc
		set credit=0
		from course inner join sc
		on sc.cno=course.cno
		where sno=@sno and @cno=sc.cno
end